
<div class="col-md-3 col-sm-6" style="margin-bottom: 30px;">
	<a href="{{$a_url}}">
	   <div class="ts-service-box-bg text-center menu-button" style="background-image:linear-gradient(to bottom, rgba(0,0,0,0.7), rgba(0,0,0,0.5)), url('{{  $image_url ? $image_url : asset('images/menu-icon/icon1.jpg') }}'); background-size: 100%;">
	      <div class="ts-service-box-content">
	         <h4>{{$title}}</h4>
	     </div>
	   </div>
   </a>
</div>